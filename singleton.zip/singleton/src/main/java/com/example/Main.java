package com.example;

public class Main {
    public static void main(String[] args) {
        new ServiceClient().ajouter_client(new Client("Haddad", "Mohamed", "Java dev"));
        new ServicePayement().ajouter_payement(new Client("Haddad", "Mohamed", "Java dev"), "1000");
        new ServicePayement().ajouter_payement(new Client("Haddad", "Mohamed", "Java dev"), "1000");
        new ServicePayement().ajouter_payement(new Client("Haddad", "Mohamed", "Java dev"), "1000");
        new ServicePayement().ajouter_payement(new Client("Haddad", "Mohamed", "Java dev"), "1000");

        Singleton.getInstance().printMessage();
    }
}
