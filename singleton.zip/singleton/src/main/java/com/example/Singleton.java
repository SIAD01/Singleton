package com.example;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Singleton {
    private static volatile Singleton instance;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final List<String> message = new ArrayList<>();

    private Singleton() {}

    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) {
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }

    public synchronized void AddMessage(String msg){
        message.add("[%s] %s".formatted(LocalTime.now().format(FMT),msg));
        System.out.println("add");
    }

    public synchronized void printMessage(){
        for(String s : message)
            System.out.println(s);
    }
}
