package com.example;

public class Client {
    private String name;
    private String prenom;
    private String job;

    public Client(String name, String prenom, String job) {
        this.name = name;
        this.prenom = prenom;
        this.job = job;
    }

    public String getName()   { return name; }
    public String getPrenom() { return prenom; }
    public String getJob()    { return job; }
}
