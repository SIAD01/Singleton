package com.example;

public class ServiceClient {
    public void ajouter_client(Client c) {
        Singleton.getInstance().AddMessage("Insertion ="+c.getName() + " " + c.getPrenom() + " " + c.getJob());
    }
}
