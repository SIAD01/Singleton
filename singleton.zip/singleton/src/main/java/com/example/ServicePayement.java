package com.example;

public class ServicePayement {
    public void ajouter_payement(Client c, String number) {
        Singleton.getInstance().AddMessage("montant=" + c.getName() + " " + c.getPrenom() + " " + number);
    }
}
